import mongoose from "mongoose";

const coursesSchema = new mongoose.Schema({
    username:{
       type:String,
       
    },
   
},
{timestamps:true}
);

const Coursesmodel = mongoose.model('courses',coursesSchema);

export default Coursesmodel