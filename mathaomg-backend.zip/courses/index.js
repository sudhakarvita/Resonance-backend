import { Router } from "express";

import{
} from "./controller.js"

const router = new Router();